#!/bin/bash
# Installs all Shirota fonts for the current user (no admin password needed).
cd "$(dirname "$0")" || exit 1
DEST="$HOME/Library/Fonts"
mkdir -p "$DEST"
count=0
for f in fonts/*.ttf; do
  xattr -d com.apple.quarantine "$f" 2>/dev/null
  cp -f "$f" "$DEST/" && count=$((count + 1))
done
echo ""
echo "Installed $count Shirota fonts into $DEST"
echo "Quit and reopen Figma (or any open app) to see Shirota, Shirota Wide and Shirota Expanded."
echo ""
read -n 1 -s -r -p "Press any key to close this window."
